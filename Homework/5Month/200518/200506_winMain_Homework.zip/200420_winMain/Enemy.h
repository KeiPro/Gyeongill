#pragma once
#include "GameNode.h"

class Image;
class MissileManager;
class Enemy : public GameNode
{
private:

	// 200518 Enemy����
	Image* image;
	MissileManager* missileMgr;
	int currentFrameX, currentFrameY;
	int updateCount;

	FPOINT pos;
	int size;
	float angle;
	float speed;

	char szText[60];

public:
	virtual HRESULT Init();
	virtual HRESULT Init(float posX, float posY);
	virtual void Release();
	virtual void Update();
	virtual void Render(HDC hdc);

	FPOINT GetPos() { return pos; }

	Enemy();
	~Enemy();
};

