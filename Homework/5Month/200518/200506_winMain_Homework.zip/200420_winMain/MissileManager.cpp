#include "MissileManager.h"
#include "Missile.h"


HRESULT MissileManager::Init()
{
	missile = new Missile();
	timer = 0;

	return S_OK;
}

HRESULT MissileManager::Init(float _posX, float _posY)
{
	maxMissileCount = 5;
	missile = new Missile[maxMissileCount];
	for (int i = 0; i < maxMissileCount; i++)
	{
		missile[i].Init(_posX, _posY);
	}

	timer = 0;
	return S_OK;
}


void MissileManager::Release()
{
	for (int i = 0; i < 5; i++)
	{
		missile[i].Release();
	}

	delete[] missile;
}

void MissileManager::Update(int posX, int posY)
{
	if (missile)
	{
		for (int i = 0; i < maxMissileCount; i++)
		{
			missile[i].Update();
		}

		timer++;

		if (timer >= 180)
		{
			for (int i = 0; i < maxMissileCount; i++)
			{
				if (missile[i].GetIsFire() == false)
				{
					missile[i].SetIsFire(true);
					FPOINT pos;
					pos.x = posX;
					pos.y = posY;
					missile[i].SetPos(pos);
					timer = 0;
					break;
				}
			}
		}
	}
	
	//timer++;
	//if (timer >= 300)
	//{
	//	timer = 0;
	//	
	//	for (int i = 0; i < maxMissileCount; i++)
	//	{
	//		missile[i].SetIsFire(true);
	//	}
	//	->SetIsFire(true);
	//}
}

void MissileManager::Render(HDC hdc)
{
	if (missile)
	{
		for (int i = 0; i < maxMissileCount; i++)
		{
			missile[i].Render(hdc);

		}
	}
}
