#include "MissileManager.h"
#include "Missile.h"


HRESULT MissileManager::Init()
{
	missiles = new Missile();
	missiles->Init(posX);
	timer = 0;

	return S_OK;
}

void MissileManager::Release()
{
	missiles->Release();
	delete missiles;
}

void MissileManager::Update()
{
	timer++;
	if (timer >= 300)
	{
		missiles->SetIsFire(true);
	}
}

void MissileManager::Render(HDC hdc)
{
	missiles->Render(hdc);
}
