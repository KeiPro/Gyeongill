#include "Image.h"

#pragma comment (lib, "msimg32.lib")


HRESULT Image::Init(int width, int height)
{
	HDC hdc = GetDC(g_hWnd);

	imageInfo = new IMAGE_INFO;
	imageInfo->resID = 0;
	imageInfo->hMemDC = CreateCompatibleDC(hdc);
	imageInfo->hBitmap = CreateCompatibleBitmap(hdc, width, height);
	imageInfo->hOldBit = (HBITMAP)SelectObject(
		imageInfo->hMemDC, imageInfo->hBitmap);
	imageInfo->width = width;
	imageInfo->height = height;

	ReleaseDC(g_hWnd, hdc);

	if (imageInfo->hBitmap == NULL)
	{
		// �޸� ����
		Release();
		return E_FAIL;
	}

	blendFunc.AlphaFormat = 0; //�⺻���� �Ǿ��ִ� ���� ���.
	blendFunc.BlendFlags = 0;
	blendFunc.BlendOp = AC_SRC_OVER;
	blendFunc.SourceConstantAlpha = 0;

	return S_OK;
}

HRESULT Image::Init(const DWORD resID, int width, int height, bool trans, COLORREF transColor)
{
	return E_NOTIMPL;
}

HRESULT Image::Init(const char * fileName, int width, int height, bool trans, COLORREF transColor)
{
	HDC hdc = GetDC(g_hWnd);

	imageInfo = new IMAGE_INFO;
	imageInfo->resID = 0;
	imageInfo->hMemDC = CreateCompatibleDC(hdc);
	imageInfo->hBitmap = (HBITMAP)LoadImage(g_hInstance, fileName, 
		IMAGE_BITMAP, width, height, LR_LOADFROMFILE);
	imageInfo->hOldBit = (HBITMAP)SelectObject(
		imageInfo->hMemDC, imageInfo->hBitmap);
	imageInfo->width = width;
	imageInfo->height = height;

	isTrans = trans;
	this->transColor = transColor;

	ReleaseDC(g_hWnd, hdc);

	if (imageInfo->hBitmap == NULL)
	{
		// �޸� ����
		Release();
		return E_FAIL;
	}

	blendFunc.AlphaFormat = 0; //�⺻���� �Ǿ��ִ� ���� ���.
	blendFunc.BlendFlags = 0;
	blendFunc.BlendOp = AC_SRC_OVER;
	blendFunc.SourceConstantAlpha = 0;

	return S_OK;
}

HRESULT Image::Init(const char * fileName,
	float x, float y, int width, int height,
	int keyFrameX, int keyFrameY,
	bool trans, COLORREF transColor)
{
	HDC hdc = GetDC(g_hWnd);

	imageInfo = new IMAGE_INFO;
	imageInfo->resID = 0;
	imageInfo->hMemDC = CreateCompatibleDC(hdc);
	imageInfo->hBitmap = (HBITMAP)LoadImage(g_hInstance, fileName,
		IMAGE_BITMAP, width, height, LR_LOADFROMFILE);
	imageInfo->hOldBit = (HBITMAP)SelectObject(
		imageInfo->hMemDC, imageInfo->hBitmap);
	imageInfo->width = width;
	imageInfo->height = height;
	// �߰�
	imageInfo->x = x - (width / 2);
	imageInfo->y = y - (height / 2);
	imageInfo->currentKeyFrameX = 0;
	imageInfo->currentKeyFrameY = 0;
	imageInfo->maxKeyFrameX = keyFrameX - 1;
	imageInfo->maxKeyFrameY = keyFrameY - 1;
	imageInfo->keyFrameWidth = width / keyFrameX;
	imageInfo->keyFrameHeight = height / keyFrameY;

	isTrans = trans;
	this->transColor = transColor;

	ReleaseDC(g_hWnd, hdc);

	if (imageInfo->hBitmap == NULL)
	{
		// �޸� ����
		Release();
		return E_FAIL;
	}

	blendFunc.AlphaFormat = 0; //�⺻���� �Ǿ��ִ� ���� ���.
	blendFunc.BlendFlags = 0;
	blendFunc.BlendOp = AC_SRC_OVER;
	blendFunc.SourceConstantAlpha = 0;

	return S_OK;
}

void Image::Release()
{
	if (imageInfo)
	{
   		SelectObject(imageInfo->hMemDC, imageInfo->hOldBit);
		DeleteObject(imageInfo->hBitmap);
		DeleteDC(imageInfo->hMemDC);

		delete imageInfo;
	}
}

void Image::Render(HDC hdc, int destX, int destY)
{
	if (isTrans)
	{
		GdiTransparentBlt(
			hdc,
			destX - imageInfo->width / 2 , destY - imageInfo->height / 2,
			imageInfo->width, imageInfo->height,

			imageInfo->hMemDC,
			0, 0,
			imageInfo->width, imageInfo->height,
			transColor
		);
	}
	else
	{
		// �޸𸮿� �ִ� �����͸� ȭ�鿡 ���Ӻ����Ѵ�.
		BitBlt(hdc,				// ���� ������ DC
			destX, destY,		// ���� ���� ��ġ
			imageInfo->width,	// �������� ����� ���� ũ��
			imageInfo->height,	// �������� ����� ���� ũ��
			imageInfo->hMemDC,	// ���� DC
			0, 0,				// �������� ���� ���� ��ġ
			SRCCOPY);			// ���� �ɼ�
	}

}

void Image::FrameRender(HDC hdc, int destX, int destY,
	int currentKeyFrameX, int currentKeyFrameY, float scale/* = 1.0f*/)
{
	// ���� Ű������ �ε����� �ִ� Ű������ �ε������� Ŭ ��
	imageInfo->currentKeyFrameX = currentKeyFrameX;
	imageInfo->currentKeyFrameY = currentKeyFrameY;

	if (imageInfo->currentKeyFrameX > imageInfo->maxKeyFrameX)
	{
		imageInfo->currentKeyFrameX = imageInfo->maxKeyFrameX;
	}
	if (imageInfo->currentKeyFrameY > imageInfo->maxKeyFrameY)
	{
		imageInfo->currentKeyFrameY = imageInfo->maxKeyFrameY;
	}

	if (isTrans)
	{
		GdiTransparentBlt(
			hdc,
			destX - (imageInfo->keyFrameWidth / 2),
			destY - (imageInfo->keyFrameHeight / 2),
			imageInfo->keyFrameWidth * scale,
			imageInfo->keyFrameHeight * scale,

			imageInfo->hMemDC,
			imageInfo->keyFrameWidth * imageInfo->currentKeyFrameX,
			imageInfo->keyFrameHeight * imageInfo->currentKeyFrameY,
			imageInfo->keyFrameWidth,
			imageInfo->keyFrameHeight,
			transColor
		);
	}
	else
	{
		BitBlt(hdc,			
			destX, destY,	
			imageInfo->keyFrameWidth,
			imageInfo->keyFrameHeight,
			imageInfo->hMemDC,
			imageInfo->keyFrameWidth * imageInfo->currentKeyFrameX,
			imageInfo->keyFrameHeight * imageInfo->currentKeyFrameY,
			SRCCOPY);		
	}

}

void Image::AlphaRender(HDC hdc, BYTE alpha, int destX, int destY, bool isTrans, COLORREF transColor)
{
	blendDC = ImageManager::GetSingleton()->AddImage("Blend", imageInfo->width, imageInfo->height);
	//blendDC->Init(imageInfo->width, imageInfo->height);

	//������ ����.
	blendFunc.SourceConstantAlpha = alpha;

	if (isTrans)
	{
		// 1. ������ DC(������� DC)�� �׷��� �ִ� ������ blend bitmap�� ���� ���� blend DC�� ����
		// 2. ����� �̹����� blend DC�� ������ ������ �����ؼ� ����
		// 3. blend DC�� ������ ������ DC�� ����.
		BitBlt(blendDC->GetMemDC(), 0, 0, imageInfo->width, imageInfo->height, hdc, destX - imageInfo->width / 2, destY - imageInfo->height / 2, SRCCOPY);
		
		GdiTransparentBlt(
			blendDC->GetMemDC(),
			0, 0,
			imageInfo->width, imageInfo->height,

			imageInfo->hMemDC,
			0, 0,
			imageInfo->width, imageInfo->height,
			transColor);

		AlphaBlend(hdc, destX - imageInfo->width / 2, destY - imageInfo->height / 2, imageInfo->width, imageInfo->height,
			blendDC->GetMemDC(), 0, 0, imageInfo->width, imageInfo->height,
			blendFunc);
	}
	else
	{
		AlphaBlend(hdc, destX - imageInfo->width / 2, destY - imageInfo->height / 2, imageInfo->width, imageInfo->height,
			imageInfo->hMemDC, 0, 0, imageInfo->width, imageInfo->height,
			blendFunc);
	}
}

void Image::RotateImage(HDC hdc, BYTE alpha, float angle, int destX, int destY, bool isTrans, COLORREF transColor)
{
	POINT pt[3], rotPt[3];
	blendDC = ImageManager::GetSingleton()->AddImage("Blend", imageInfo->width, imageInfo->height);
	transDC = ImageManager::GetSingleton()->AddImage("TransDC", imageInfo->width, imageInfo->height);
	rotDC = ImageManager::GetSingleton()->AddImage("RotDC", imageInfo->width, imageInfo->height);
	//������ ����.
	blendFunc.SourceConstantAlpha = alpha;


	//centerX = destX - imageInfo->width / 2;
	//centerY = destY - imageInfo->height / 2;

	pt[0].x = destX - imageInfo->width / 2;
	pt[0].y = destY - imageInfo->height / 2;
	pt[1].x = destX + imageInfo->width / 2;
	pt[1].y = destY - imageInfo->height / 2;
	pt[2].x = destX - imageInfo->width / 2;
	pt[2].y = destY + imageInfo->height / 2;

	for (int i = 0; i < 3; i++)
	{
		pt[i].x -= destX;
		pt[i].y -= destY;
	}

	for (int i = 0; i < 3; i++)
	{
		rotPt[i].x = pt[i].x * cosf(DEGREE_TO_RADIAN(angle)) - pt[i].y * sinf(DEGREE_TO_RADIAN(angle));
		rotPt[i].y = pt[i].x * sinf(DEGREE_TO_RADIAN(angle)) + pt[i].y * cosf(DEGREE_TO_RADIAN(angle));
	}

	if (isTrans)
	{
		// 1. ������ DC(������� DC)�� �׷��� �ִ� ������ blend bitmap�� ���� ���� blend DC�� ����
		// 2. ����� �̹����� blend DC�� ������ ������ �����ؼ� ����
		// 3. blend DC�� ������ ������ DC�� ����.
		BitBlt(blendDC->GetMemDC(), 0, 0, imageInfo->width * 2, imageInfo->height * 2, hdc, destX - imageInfo->width / 2, destY - imageInfo->height / 2, SRCCOPY);

		GdiTransparentBlt(
			transDC->GetMemDC(),
			0, 0,
			imageInfo->width, imageInfo->height,

			imageInfo->hMemDC,
			0, 0,
			imageInfo->width, imageInfo->height,
			transColor);

		PlgBlt(rotDC->GetMemDC(), rotPt, transDC->GetMemDC(), 0, 0, imageInfo->width, imageInfo->height, 0, 0, 0);

		//BitBlt(blendDC->GetMemDC(), 0, 0, imageInfo->width * 2, imageInfo->height * 2, rotDC->GetMemDC(), -, destY - imageInfo->height / 2, SRCCOPY);

		AlphaBlend(hdc, destX - imageInfo->width / 2, destY - imageInfo->height / 2, imageInfo->width, imageInfo->height,
			blendDC->GetMemDC(), 0, 0, imageInfo->width, imageInfo->height,
			blendFunc);
	}
	else
	{
		AlphaBlend(hdc, destX - imageInfo->width / 2, destY - imageInfo->height / 2, imageInfo->width, imageInfo->height,
			imageInfo->hMemDC, 0, 0, imageInfo->width, imageInfo->height,
			blendFunc);
	}

	



}

//BOOL Image::RotateSizingImage(HDC hdc, HBITMAP hBmp, double dblAngle, int ixRotateAxis, int iyRotateAxis, int ixDisplay, int iyDisplay, double dblSizeRatio, HBITMAP hMaskBmp, int ixMask, int iyMask)
//{
//	int i;
//	BITMAP bm;
//	GetObject(hBmp, sizeof(BITMAP), &bm);
//	POINT apt[3] = { 0 };
//	double dblWidth = (double)bm.bmWidth*dblSizeRatio;
//	double dblHeight = (double)bm.bmHeight*dblSizeRatio;
//	double ixRotate = (int)((double)ixRotateAxis*dblSizeRatio); // ũ�Ⱑ ���ϴ� �� ����
//	double iyRotate = (int)((double)iyRotateAxis*dblSizeRatio);
//	const double pi = 3.14159265358979323846;
//
//
//	double dblRadian, dblx, dbly, dblxDest, dblyDest, cosVal, sinVal;
//	dblRadian = dblAngle * pi / 180.0f;
//	cosVal = cos(dblRadian), sinVal = sin(dblRadian);
//
//	// 1. ȸ������ �������� �����ǥ�� ���ϰ�
//	// 2. ȸ���� ��ġ��ǥ(�����ǥ)�� ���� ��
//	// 3. ���� ���� ������ ��ǥ�� ����.
//	for (i = 0; i < 3; i++) {
//		if (i == 0) { dblx = -ixRotate, dbly = -iyRotate; }    // left up  ������ �κ�
//		else if (i == 1) { dblx = dblWidth - ixRotate, dbly = -iyRotate; }  // right up ������ �κ�
//		else if (i == 2) { dblx = -ixRotate, dbly = dblHeight - iyRotate; } // left low ������ �κ�
//		dblxDest = dblx * cosVal - dbly * sinVal;
//		dblyDest = dblx * sinVal + dbly * cosVal;
//		dblxDest += ixRotate, dblyDest += iyRotate;
//		apt[i].x = ixDisplay - (long)ixRotate + (long)dblxDest;
//		apt[i].y = iyDisplay - (long)iyRotate + (long)dblyDest;
//	}
//
//	HDC hMemdc;
//	HBITMAP hOldBmp;
//	hMemdc = CreateCompatibleDC(hdc);
//	hOldBmp = (HBITMAP)SelectObject(hMemdc, hBmp);
//	BOOL iRes = PlgBlt(hdc, apt, hMemdc, ixDisplay, iyDisplay, bm.bmWidth, bm.bmHeight, hMaskBmp, ixMask, iyMask);
//	SelectObject(hMemdc, hOldBmp);
//	DeleteDC(hMemdc);
//	return iRes;
//}

Image::Image()
{
}


Image::~Image()
{
}

