#include "GameNode.h"



HRESULT GameNode::Init()
{
	return S_OK;
}

void GameNode::Release()
{
}

void GameNode::Update()
{
}

void GameNode::Render(HDC hdc)
{
}

GameNode::GameNode()
{
}


GameNode::~GameNode()
{
}
