#include "SpaceShip.h"
#include "Image.h"
#include "MissileManager.h"

HRESULT SpaceShip::Init()
{
	image = ImageManager::GetSingleton()->AddImage("SpaceShip", "Image/rocket.bmp", 52, 64, true, RGB(255, 0, 255));

	if (image == nullptr)
	{
		return E_FAIL;
	}

	//_backBuffer = new Image();
	//_backBuffer->Init(WINSIZE_X, WINSIZE_Y);

	missileMgr = new MissileManager();
	missileMgr->Init();
	missileMgr->SetOwner(this);

	angle = 0.0f;
	moveSpeed = 200.0f;
	pos.x = WINSIZE_X / 2;
	pos.y = WINSIZE_Y - 120;
	//rotateAngle = 0.0f;

	hideValue = 255;
	isDamaged = false;

	return S_OK;
}

void SpaceShip::Release()
{
	//_backBuffer->Release();
	//delete _backBuffer;

	missileMgr->Release();
	delete missileMgr;
}

void SpaceShip::Update()
{
	//
	//rotateAngle += 1;

	if (KeyManager::GetSingleton()->IsStayKeyDown(VK_LEFT))
	{
		pos.x -= moveSpeed * TimeManager::GetSingleton()->GetDeltaTime();
	}
	else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_RIGHT))
	{
		pos.x += moveSpeed * TimeManager::GetSingleton()->GetDeltaTime();
	}

	if (KeyManager::GetSingleton()->IsStayKeyDown(VK_UP))
	{
		pos.y -= moveSpeed * TimeManager::GetSingleton()->GetDeltaTime();
	}
	else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_DOWN))
	{
		pos.y += moveSpeed * TimeManager::GetSingleton()->GetDeltaTime();
	}

	if (missileMgr)
	{
		if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_SPACE))
		{
			missileMgr->Fire();
		}

		missileMgr->Update();
	}
	

	if (isDamaged)
	{

	}
}

void SpaceShip::Render(HDC hdc)
{
	if (image)
	{
		//image->AlphaRender(hdc, hideValue, pos.x, pos.y, true, RGB(255,0,255));
		image->RotateAlphaRender(hdc, 0, pos.x, pos.y, 255);
	}

	if (missileMgr)
	{
		missileMgr->Render(hdc);
	}
}
