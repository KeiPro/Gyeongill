#include "pch.h"
#include "macroFunction.h"
#include "Enemy.h"
#include "Tank.h"
#include "Image.h"
#include "MissileManager.h"


HRESULT Enemy::Init()
{
	pos.x = WINSIZE_X / 2;
	pos.y = 120;

	currentFrameX = currentFrameY = 0;
	updateCount = 0;

	speed = 1.0f;
	angle = PI;
	size = 40;

	fireDelay = rand() % 200 + 300;
	fireCount = 0;

	missileMgr = new MissileManager();
	missileMgr->Init();
	missileMgr->SetOwner(this);
	return S_OK;
}



HRESULT Enemy::Init(float posX, float posY)
{
	pos.x = posX;
	pos.y = posY;

	/*missileMgr = new MissileManager();*/

	ImageManager::GetSingleton()->AddImage("UFO", "Image/ufo.bmp", pos.x, pos.y, 530, 32, 10, 1, true, RGB(255, 0, 255));
	image = ImageManager::GetSingleton()->FindImage("UFO");

	//image = new Image();

	//if (FAILED(image->Init("Image/ufo.bmp", pos.x, pos.y, 530, 32, 10, 1, true, RGB(255, 0, 255))))
	//{
	//	MessageBox(g_hWnd, "Image/ufo.bmp ����", "Enemy.cpp", MB_OK);

	//	return E_FAIL;
	//}

	currentFrameX = currentFrameY = 0;
	updateCount = 0;

	speed = 1.0f;
	angle = PI;
	size = 40;

	fireDelay = rand() % 200 + 300;
	fireCount = 0;

	missileMgr = new MissileManager();
	missileMgr->Init();
	missileMgr->SetOwner(this);


	return S_OK;
}


void Enemy::Release()
{
	//image->Release();
	//SAFE_DELETE(image);

	missileMgr->Release();
	SAFE_DELETE(missileMgr);
}

void Enemy::Update()
{
	if (image)
	{
		updateCount++;
		if (updateCount % 3 == 0)
		{
			currentFrameX++;
			updateCount = 0;
		}

		if (currentFrameX > image->GetMaxKeyFrameX())
		{
			currentFrameX = 0;
		}
	}


	if (missileMgr)
	{
		fireCount++;
		if (fireCount > fireDelay)
		{
			if (missileMgr->Fire())
			{
				fireCount = 0;
				fireDelay = rand() % 200 + 300;
			}
		}

		missileMgr->Update();
	}

}

void Enemy::Render(HDC hdc)
{
	if (missileMgr)
	{
		missileMgr->Render(hdc);
	}

	if (image)
	{
		image->FrameRender(hdc, pos.x, pos.y, currentFrameX, currentFrameY);
	}

	//wsprintf(szText, "currentFrameX : %d", image->GetMaxKeyFrameX());
	//TextOut(hdc, 250, 500, szText, strlen(szText));

	//RenderEllipseToCenter(hdc, pos.x, pos.y, size, size);
}

//
//void Enemy::SetTarget(Tank * tank)
//{
//	float x = (float)(target->GetCenter().x) - pos.x;
//	float y = (float)(target->GetCenter().y) - pos.y;
//
//	angle = atan2(-y, x);
//}

Enemy::Enemy()
{
}


Enemy::~Enemy()
{
}
