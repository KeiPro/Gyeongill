#include "MissileFactory.h"
#include "Missile.h"

void MissileFactory::NewMissile()
{
	Missile* m = CreateMissile();
	missileDatas.push_back(m);
	m->Notice();
}

MissileFactory::MissileFactory()
{
}

MissileFactory::~MissileFactory()
{
}

Missile * NormalMissileFactory::CreateMissile()
{
	return new NormalMissile();
}

NormalMissileFactory::NormalMissileFactory()
{
}

NormalMissileFactory::~NormalMissileFactory()
{
}

Missile* LazerMissileFactory::CreateMissile()
{
	return new LazerMissile();
}

LazerMissileFactory::LazerMissileFactory()
{
}

LazerMissileFactory::~LazerMissileFactory()
{
}
