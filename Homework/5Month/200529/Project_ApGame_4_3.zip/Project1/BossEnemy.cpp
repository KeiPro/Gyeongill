#include "BossEnemy.h"

HRESULT BossEnemy::Init()
{
	pos = { 0.0f , 0.0f };
	speed = 10.0f;
	life = 1;

	return S_OK;
}

void BossEnemy::Release()
{
}

void BossEnemy::Update()
{

}

void BossEnemy::Render(HDC hdc)
{

}
