#pragma once
#include "GameNode.h"

class Image;
class EnemyManager;
class Player;
class EliteEnemy;
class Battle : public GameNode
{
private:

	//0526 ���� 
	Image* backgroundImg;
	int sourceX; //����� �����̰� �ϱ� ���� ����.
	Player* player;

	int charNum;
	EnemyManager* enemyMgr;
	EliteEnemy* eliteEnemy;

public:
	virtual HRESULT Init(int selectIdx);
	virtual void Update();
	virtual void Release();
	virtual void Render(HDC hdc);

	void SetCharNum(int _charNum) { charNum = _charNum; }
	static Battle* instance;
	EnemyManager* GetEnemyMgr() { return enemyMgr; }
	int GetCharNum() { return charNum; }
	FPOINT GetPlayerPos();
	Player* GetPlayer() { return player; }


};

