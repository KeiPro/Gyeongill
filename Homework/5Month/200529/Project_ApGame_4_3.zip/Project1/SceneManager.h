#pragma once
#include "GameNode.h"

class Image;
class Battle;
class SceneManager : public GameNode
{
private:
	int sceneNum;
	int charNum;

	Image* selectBGImg;
	Image* selectPointerImg;

	//test�� ����
	//FPOINT pos;
	float selectPosX[3] { 0, 500, 1000 };
	int width, height;
	bool isSelected;
	Battle* battle;

public:
	virtual HRESULT Init();
	virtual void Update();
	virtual void Release();
	virtual void Render(HDC hdc);

	int CharSelect();
};

