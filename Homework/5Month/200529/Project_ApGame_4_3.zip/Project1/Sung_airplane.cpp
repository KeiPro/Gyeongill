#include "Sung_airplane.h"
#include "Image.h"
#include "MissileManager.h"

HRESULT Sung_airplane::Init()
{
	speed = 5.0f;
	pos = { 50, WINSIZE_Y / 2 };
	
	currFrameX = 0;
	currFrameY = 0;
	radius = 0;
	life = 1;
	img = ImageMgr::GetSingleton()->AddImage("Akainu.Idle", "Image/akainu.bmp", 0, 0, 2400, 400, 12, 4, true, RGB(88, 95, 142));
	maxKeyFrameX = 3;

	//0527 �߰�
	isAvoid = false;			// ȸ�Ǳ⸦ ����� �� �ִ����� üũ�� ����.
	elipsedTime = 0;			// �����Ӵ� �����ϴ� ����.
	playerState = PlayerState::IDLE; //�⺻ ���´� Idle�����̴�.
	avoidGage = 0;		// ȸ�Ǳ��� �������� ����� ����


	missileMgr = new MissileManager();
	missileMgr->Init();
	missileMgr->SetObject(this);

	return S_OK;
}

void Sung_airplane::Release()
{

}

void Sung_airplane::Update()
{
	if (life == 1)
	{
		if (isAvoid == false)
		{
			avoidGage++;
			if (avoidGage >= 300) avoidGage = 300;
		}

		elipsedTime++;

		if (/*(isAvoid == false) && */(playerState == PlayerState::IDLE || playerState == PlayerState::BACK || playerState == PlayerState::AVOID))
		{
			if (KeyManager::GetSingleton()->IsStayKeyDown(VK_RIGHT))
			{
				playerState = PlayerState::IDLE;
				pos.x += speed;
			}
			else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_LEFT))
			{
				playerState = PlayerState::BACK;
				pos.x -= speed;
			}

			if (KeyManager::GetSingleton()->IsStayKeyDown(VK_UP))
			{
				playerState = PlayerState::IDLE;
				pos.y -= speed;
			}
			else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_DOWN))
			{
				playerState = PlayerState::IDLE;
				pos.y += speed;
			}

			if (KeyManager::GetSingleton()->IsOnceKeyUp(VK_LEFT))
			{
				playerState = PlayerState::IDLE;
			}
		}

		if (KeyManager::GetSingleton()->IsOnceKeyDown('Z'))
		{
			missileMgr->Fire(pos.x, pos.y, 0);
			missileMgr->SetIsEnemy(false);
		}

		if (KeyManager::GetSingleton()->IsStayKeyDown('C'))
		{
			playerState = PlayerState::AVOID;
		}

		if (KeyManager::GetSingleton()->IsOnceKeyDown('X'))
		{
			playerState = PlayerState::SKILL;
		}

		if (KeyManager::GetSingleton()->IsOnceKeyUp('C'))
		{
			playerState = PlayerState::IDLE;
		}
	}
	else
	{

	}

	switch (playerState)
	{
	case PlayerState::IDLE:

		currFrameY = 0;

		if (elipsedTime % 5 == 0)
		{
			currFrameX++;
			elipsedTime = 0;
		}

		if (currFrameX > maxFrameX[currFrameY])
		{
			currFrameX = 0;
		}

		break;

	case PlayerState::BACK:

		currFrameY = 1;

		if (elipsedTime % 5 == 0)
		{
			currFrameX++;
			elipsedTime = 0;
		}

		if (currFrameX > maxFrameX[currFrameY])
		{
			currFrameX = 0;
		}

		break;


	case PlayerState::SKILL:

		currFrameY = 2;

		if (elipsedTime % 3 == 0)
		{
			currFrameX++;
			elipsedTime = 0;
		}

		if (currFrameX > maxFrameX[currFrameY])
		{
			currFrameX = 0;
			playerState = PlayerState::IDLE;
		}

		break;


	case PlayerState::AVOID:

		currFrameY = 3;

		if (elipsedTime % 3 == 0)
		{
			currFrameX++;
			elipsedTime = 0;
		}

		if (currFrameX > maxFrameX[currFrameY])
		{
			currFrameX = 0;
		}


		break;
	}

	missileMgr->Update();
}

void Sung_airplane::Render(HDC hdc)
{
	if (img)
	{
		img->FrameRender(hdc, pos.x, pos.y, currFrameX, currFrameY, 1.7f);
	}

	if (missileMgr)
		missileMgr->Render(hdc);
}
