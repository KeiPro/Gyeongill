#include "Object.h"

HRESULT Object::Init()
{
	return S_OK;
}

void Object::Update()
{

}

void Object::Release()
{

}

void Object::Render()
{

}
