#include "EliteEnemy.h"
#include "Image.h"
#include "MissileManager.h"
#include "macroFunction.h"

HRESULT EliteEnemy::Init()
{
	img = ImageMgr::GetSingleton()->AddImage("Whitebeard", "Image/Whitebeard.bmp", 0, 0, 800, 300, 4, 2, true, RGB(117, 126, 243));

	pos.x = WINSIZE_X;
	pos.y = WINSIZE_Y / 2;

	currFrameX = 0;
	currFrameY = 0;

	elipsedTime = 0;
	myState = 0;
	missileAngle = 0;
	

	eliteEnemyState = EliteEnemyState::IDLE;

	enemyMissile = new MissileManager();
	enemyMissile->Init(true);

	//isCircle = false;
	speed = 10.0f;
	life = 1;
	isAppear = false;
	frameRate = 0;
	upState = false;
	downState = false;
	angle = 180;
	patternFrame = 0;
	motionDelay = 0;
	isMotionDelay = false;
	isForwardRotate = true;

	fireFrame = 0;
	fireDelay = 1;

	return S_OK;
}

void EliteEnemy::Release()
{
	enemyMissile->Release();
	SAFE_DELETE(enemyMissile);
}

void EliteEnemy::Update()
{
	if (isAppear)
	{
		elipsedTime++;

		if (eliteEnemyState == EliteEnemy::IDLE)
		{
			frameRate++; //���� ��ȭ�� �ֱ� ���� ������ ����.
		}
		
		if ( frameRate >= 120 ) //ó���� �����ϰ� 120�������� ������(4��) Pattern1���·� ��ȭ.
		{
			frameRate = 0;
			myState = 1;
			currFrameY = myState;
			upState = true;
			eliteEnemyState = EliteEnemyState::PATTERN1;
		}

		if (pos.x >= WINSIZE_X * 2 / 3) // �������� 3���� 2��������� �´�.
		{
			pos.x -= speed;
		}

		//if (angle >= 90)
		//{
		//	angle = 0;
		//	fireDelay--;
		//	if (fireDelay < 1)
		//	{
		//		fireDelay = 1;
		//	}
		//}
		//	

		enemyMissile->Update();

		switch (eliteEnemyState)
		{
		case EliteEnemyState::IDLE:

			if (elipsedTime % 5 == 0)
			{
				currFrameX++;
				elipsedTime = 0;
			}

			if (currFrameX > maxFrameX[myState])
			{
				currFrameX = 0;
			}

			break;

	
		case EliteEnemyState::PATTERN1:

			fireFrame++;

			// angle���� ��ȭ���ִ� �ڵ�
			if (isMotionDelay == false)
			{
				patternFrame++;

				if (patternFrame <= 15)
				{
					angle += 3;
					if (patternFrame == 15)
					{
						isMotionDelay = true;
					}
				}
				else
				{
					angle -= 3;

					if (patternFrame == 30)
					{
						patternFrame = 0;
						isMotionDelay = true;
					}
				}
			}
			
			// Fire �����̸� �ִ� �ڵ�
			if (fireFrame > patternDelay[(int)EliteEnemyState::PATTERN1])
			{
				if (isMotionDelay)
				{
					motionDelay++;

					if (motionDelay > 5)
					{
						motionDelay = 0;
						isMotionDelay = false;
						nextPatternFrame++;

						if (nextPatternFrame >= patternCount[0]) //���� ī��Ʈ�� 0�� Ƚ�� ���� ũ�ų� ������ 
						{
							nextPatternFrame = 0;
							eliteEnemyState = EliteEnemyState::PATTERN2;
						}
					}
				}
				else
				{

					fireFrame = 0;

					enemyMissile->SetIsEnemy(true);

					enemyMissile->Fire(pos.x - 75, pos.y + 5, angle - 80);
					enemyMissile->Fire(pos.x - 75, pos.y + 5, angle - 40);
					enemyMissile->Fire(pos.x - 75, pos.y + 5, angle);
					enemyMissile->Fire(pos.x - 75, pos.y + 5, angle + 40);
					enemyMissile->Fire(pos.x - 75, pos.y + 5, angle + 80);
				}
			}

			if (elipsedTime % 3 == 0)
			{
				currFrameX++;
				elipsedTime = 0;
			}

			if (currFrameX > maxFrameX[myState])
			{
				currFrameX = maxFrameX[myState];
			}

			break;

		case EliteEnemyState::PATTERN2:

#pragma region Pattern2

		fireFrame++;
		patternFrame++;

		if (isForwardRotate && patternFrame >= 150) //5�ʰ� ������, Idle���·� ����.
		{
			patternFrame = 0;
			fireFrame = 0;
			angle = 180;
			frameRate = 0;

			isForwardRotate = false;
		}

		if (!isForwardRotate && patternFrame >= 150) //5�ʰ� ������, Idle���·� ����.
		{
			patternFrame = 0;
			fireFrame = 0;
			angle = 180;
			frameRate = 0;
			isForwardRotate = true;

			eliteEnemyState = EliteEnemyState::IDLE;

			currFrameX = 0;
			myState = 0;
			currFrameY = myState;
		}
		
		if (isForwardRotate)
		{
			angle += 3;
		}
		else
		{
			angle -= 3;
		}

		if (fireFrame > fireDelay)
		{
			fireFrame = 0;
			enemyMissile->SetIsEnemy(true);

			enemyMissile->Fire(pos.x - 75, pos.y + 5, angle);
			enemyMissile->Fire(pos.x - 75, pos.y + 5, angle + 90);
			enemyMissile->Fire(pos.x - 75, pos.y + 5, angle + 180);
			enemyMissile->Fire(pos.x - 75, pos.y + 5, angle + 270);
		}					 

		if (elipsedTime % 3 == 0)
		{
			currFrameX++;
			elipsedTime = 0;
		}

		if (currFrameX > maxFrameX[myState])
		{
			currFrameX = maxFrameX[myState];
		}

#pragma endregion
			
			break;

		case EliteEnemyState::STAR:



			break;

		case EliteEnemyState::HEART:

			break;
		}
	}
}

void EliteEnemy::Render(HDC hdc)
{


	if (enemyMissile)
	{
		enemyMissile->Render(hdc);
	}
	DrawEllipse(hdc, pos.x - 75, pos.y + 5, 25);
	if (img)
	{
		img->FrameRender(hdc, pos.x, pos.y, currFrameX, currFrameY, 1.7f);

	}
}

void EliteEnemy::Pattern1()
{
}
