#include "Player.h"
#include "Jong_airplane.h"
#include "Sung_airplane.h"
#include "Young_airplane.h"
#include "MissileManager.h"
#include "Image.h"

HRESULT Player::Init(int selectIdx)
{
	charNum = selectIdx;

	switch (charNum)
	{
	case 0:

		young = new Young_airplane();
		young->Init();

		break;

	case 1:

		sung = new Sung_airplane();
		sung->Init();


		break;

	case 2:

		jong = new Jong_airplane();
		jong->Init();

		break;
	}

	speed = 5.0f;

	radius = 0;

	missileMgr = new MissileManager();
	missileMgr->Init();
	missileMgr->SetObject(this);

	return S_OK;
}

void Player::Update()
{
	if (charNum == 0)
	{
		young->Update();
		playerPos = young->GetPos();
	}
	else if (charNum == 1)
	{
		sung->Update();
		playerPos = sung->GetPos();
	}
	else if (charNum == 2)
	{
		jong->Update();
		playerPos = jong->GetPos();
	}

	missileMgr->Update();

}

void Player::Release()
{
	switch (charNum)
	{
	case 0:

		young->Release();
		SAFE_DELETE(young);

		break;

	case 1:

		sung->Release();
		SAFE_DELETE(sung);

		break;

	case 2:

		jong->Release();
		SAFE_DELETE(jong);

		break;
	}
}

void Player::Render(HDC hdc)
{
	if (charNum == 0)
		young->Render(hdc);
	else if (charNum == 1)
		sung->Render(hdc);
	else if (charNum == 2)
		jong->Render(hdc);

	if (missileMgr)
		missileMgr->Render(hdc);
}

bool Player::Onhit(FPOINT point)
{
	float length = sqrt(pow(point.x - pos.x, 2) + pow(point.y - pos.y, 2)); // �ΰ�ü���� �Ÿ� ��z
	if (length < 40)
	{
		isDamaged = true;
		return true;
	}
	return false;
}
