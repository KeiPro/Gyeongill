#pragma once
#include "Enemy.h"

class Iamge;
class MissileManager;
class EliteEnemy : public Enemy
{
protected:

	enum EliteEnemyState
	{
		PATTERN1, // �Ϲ� ����
		PATTERN2, // �ٶ�����
		PATTERN3,
		IDLE,
		STAR,
		HEART
	};

	int patternDelay[3]{2, 1, 0};
	int patternCount[3]{4, 0, 0}; ////////////
	int nextPatternFrame;
	
	bool isForwardRotate;

	int motionDelay;
	bool isMotionDelay;

	//0527 ���� �߰�
	int maxFrameX[2]{ 3, 2 };
	//int patternFrame[3]{ 120,  };
	//bool isCircle;

	Image* img;
	int elipsedTime;
	bool isAppear;
	int myState; //�ƽ� ������ x�� �ε����� ����� ����

	float missileAngle;

	MissileManager* enemyMissile;
	EliteEnemyState eliteEnemyState;

	bool upState;
	bool downState;
	int frameRate;

	int fireFrame;
	int fireDelay;
	int patternFrame;
	
	float angle;


public:

	virtual HRESULT Init();
	virtual void Release();
	virtual void Update();
	virtual void Render(HDC hdc);

	void SetIsAppear(bool _isAppear) { isAppear = _isAppear; }

	bool GetIsAppear() { return isAppear; }

	void Pattern1();
};

