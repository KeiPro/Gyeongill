#include "Enemy.h"

HRESULT Enemy::Init()
{
	return S_OK;
}

void Enemy::Release()
{
}

void Enemy::Update()
{

}

void Enemy::Render(HDC hdc)
{

}
