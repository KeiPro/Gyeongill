#pragma once
#include "pch.h"
#include "Object.h"

class MissileManager;
class Jong_airplane;
class Sung_airplane;
class Young_airplane;
class Player : public Object
{
private:
	int charNum;
	bool move;
	bool isDamaged;
	MissileManager* missileMgr;

	Jong_airplane* jong;
	Sung_airplane* sung;
	Young_airplane* young;
	FPOINT playerPos;
public:
	virtual HRESULT Init(int selectIdx);
	virtual void Update();
	virtual void Release();
	virtual void Render(HDC hdc);
	bool Onhit(FPOINT point);
	FPOINT GetPlayerPos() { return playerPos; }

};