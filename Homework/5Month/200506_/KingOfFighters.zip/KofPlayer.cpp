#include "KofPlayer.h"
#include "Image.h"


HRESULT KofPlayer::Init()
{
	img = new Image();
	if (FAILED(img->Init("Image/Iori_walk.bmp", 0, 0, 612, 104, 9, 1, true, RGB(255, 0, 255))))
	{
		MessageBox(g_hWnd, "Image/Iori_walk.bmp �ʱ�ȭ ����", "KofPlayer.cpp", MB_OK);

		return E_FAIL;
	}

	posX = WINSIZE_X / 2;
	posY = WINSIZE_Y - 300;
	
	currentKeyFrameX = 0;
	frameUpdate = 0;
	speed = 2.0f;


	return S_OK;
}

void KofPlayer::Release()
{
	img->Release();
	delete img;
}

void KofPlayer::Update()
{
	if (KeyManager::GetSingleton()->IsStayKeyDown(VK_RIGHT))
	{
		posX += speed;
	}
	else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_LEFT))
	{
		posX -= speed;
	}




	if (img)
	{
		frameUpdate++;
		if (frameUpdate % 10 == 0)
		{
			currentKeyFrameX++;

			if (currentKeyFrameX > 8)
			{
				currentKeyFrameX = 0;
			}
		}
	}



}

void KofPlayer::Render(HDC hdc)
{
	 

	if (img)
	{
		img->FrameRender(hdc, posX, posY, currentKeyFrameX, 0, size);
	}
}

KofPlayer::KofPlayer()
{
}


KofPlayer::~KofPlayer()
{
}
