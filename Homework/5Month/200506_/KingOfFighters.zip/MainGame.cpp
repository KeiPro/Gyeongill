#include "MainGame.h"
#include "macroFunction.h"
#include "Tank.h"
#include "Missile.h"
#include "Enemy.h"
#include "Image.h"
#include "KofPlayer.h"

HRESULT MainGame::Init()
{
	// backBuffer
	backBuffer = new Image();
	backBuffer->Init(WINSIZE_X, WINSIZE_Y); //�̹����� ���� �� �׷����� ������ �ʿ��ϴ�. �� ũ��� �� ��Ʈ���� ����� �ش�.

	KeyManager::GetSingleton()->Init(); //�� �������� static������ �޸� �Ҵ��� �ȴ�.

	hTimer = (HANDLE)SetTimer(g_hWnd, 0, 10, NULL);

	enemyCount = 5;

	// ��ũ
	tank = new Tank();
	tank->Init();

	enemy = new Enemy();
	enemy->Init();
	
	bg = new Image();
	bg->Init("Image/bmpFile/Frame0.bmp", WINSIZE_X, WINSIZE_Y);
	bgIdx = 0;

	tank->SetTarget(enemy);

	iori = new KofPlayer();
	iori->Init();
	iori->SetSize(3.0f);

	isInit = true;
	
	return S_OK;
}


void MainGame::Release()
{
	iori->Release();
	delete iori;

	bg->Release();
	delete bg;

	enemy->Release();
	delete enemy;

	tank->Release();
	delete tank;

	KillTimer(g_hWnd, 0);

	KeyManager::GetSingleton()->Release();
	KeyManager::GetSingleton()->ReleaseSingleton();

	backBuffer->Release();
	delete backBuffer;
}

void MainGame::Update()
{
	//if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_SPACE))
	//{
	//	if (enemy)
	//	{
	//		enemy->SetTarget(tank);
	//	}
	//}

	if (enemy)
	{
		enemy->Update();
	}
	
	if (tank)
	{
		tank->Update();
	}

	if (iori)
	{
		iori->Update();
	}

	InvalidateRect(g_hWnd, NULL, false); //false�� �ٲ��ش�.
}

void MainGame::Render(HDC hdc)
{	
	// ��~~ backBuffer���ٰ� �׷��ش�.

	if (bg)
	{
		
		bg->Render(backBuffer->GetMemDC(), 0, 0); 
	}

	if (tank)
	{
		tank->Render(backBuffer->GetMemDC());
	}
	
	if (enemy)
	{
		enemy->Render(backBuffer->GetMemDC());
	}

	if (iori)
	{
		iori->Render(backBuffer->GetMemDC());
	}

	backBuffer->Render(hdc, 0, 0);


	//if (bg)
	//{
	//	bg->Render(hdc, 100, 100); // 0 0 : ����� ��ġ�� ��ǥ
	//}

	////if (marble)
	////{
	////	marble->Render(hdc, 300, 300);
	////}

	//if (tank)
	//{
	//	tank->Render(hdc);	
	//}
	//	
	//if (enemy)
	//{
	//	enemy->Render(hdc);
	//}
}

LRESULT MainGame::MainProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch (iMessage)
	{
	case WM_TIMER:
		if(isInit == true)
			this->Update();
		break;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);

		if (isInit == true)
			this->Render(hdc);

		EndPaint(hWnd, &ps);
		break;
	case WM_KEYDOWN:
		switch (wParam)
		{
		case VK_LEFT:
			break;
		case VK_RIGHT:
			break;
		case VK_UP:
			break;
		case VK_DOWN:
			break;

		case VK_SPACE:

			break;
		case VK_ESCAPE:
			PostQuitMessage(0);
			break;
		}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	}

	return DefWindowProc(hWnd, iMessage, wParam, lParam);
}

bool MainGame::CheckCollision(Missile* m1, Missile* m2)
{
	float halfSize1 = m1->GetSize() / 2;
	float halfSize2 = m2->GetSize() / 2;
	FPOINT pos1 = m1->GetPos();
	FPOINT pos2 = m2->GetPos();

	if ( (halfSize1 + halfSize2) >= GetDistance(pos1.x, pos1.y, pos2.x, pos2.y) )
	{
		return true;
	}

	return false;
}

MainGame::MainGame() : isInit(false)
{
}


MainGame::~MainGame()
{
}
